For easier testing, I defined the array1 and array2 as follows:
	arr1		db	20,19,15,1,3,2,9,8,17
	arr2		db	1,2,3,4,6,7,8,9,10,11,12,13,14,15,16,18
Compile and run the code, then you can get your desired output
