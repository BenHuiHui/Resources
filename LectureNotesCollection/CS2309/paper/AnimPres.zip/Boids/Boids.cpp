#include "Boids.h"
#include <fstream>
#include <iostream>

using namespace std;

// Timer variables
float lasttime = ((float)glutGet(GLUT_ELAPSED_TIME))/1000, curtime = 0, pausetime = 0, elaptime = 0, pausetotal = 0;
float curfrtime = RAND_TIME, lastfrtime = 0;

float SPEED = (float)0.02;

void DrawBoid(BOID *boid, float radius, float slices)
{
	float theta, delta_theta, magnitude, dx, dy;

	delta_theta = (float)(2.0*M_PI/slices);
	glColor3fv(boid_color[boid->color]);

	glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
	glBegin(GL_TRIANGLE_FAN);
	glVertex2f(boid->x, boid->y);
	for (theta=0; theta<2.0*M_PI; theta+=delta_theta)
	{
		glVertex2f(boid->x+radius*cos(theta), boid->y+radius*sin(theta));
	}
	glVertex2f(boid->x+radius, boid->y);
	glEnd();

	if (boid->radius==0) {
		if (directional_sphere) {
			radius*=5;
			glColor3f(0.8f, 0.8f, 0.8f);
			glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
			glBegin(GL_LINE_STRIP);
			for (theta=0; theta<2.0*M_PI; theta+=delta_theta)
			{
				glVertex2f(boid->x+radius*cos(theta), boid->y+radius*sin(theta));
			}
			glVertex2f(boid->x+radius, boid->y);
			glEnd();

			magnitude = sqrt((boid->dx*boid->dx)+(boid->dy*boid->dy));
			dx=(boid->dx/magnitude)*RADIUS*5;
			dy=(boid->dy/magnitude)*RADIUS*5;

			glColor3f(0.2f, 0.2f, 0.2f);
			glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
			glBegin(GL_LINE_STRIP);
			glVertex2f(boid->x, boid->y);
			glVertex2f(boid->x+dx, boid->y+dy);
			glEnd();
		}
		
		if (collision_vector) {
			magnitude = sqrt((boid->aex*boid->aex)+(boid->aey*boid->aey));
			dx=(boid->aex/magnitude)*RADIUS*5;
			dy=(boid->aey/magnitude)*RADIUS*5;
			
			if (magnitude>0) {
			glColor3f(1.0f, 0.0f, 0.0f);
			glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
			glBegin(GL_LINE_STRIP);
			glVertex2f(boid->x, boid->y);
			glVertex2f(boid->x+dx, boid->y+dy);
			glEnd();
			}
		}

		if (velocity_vector) {
			magnitude = sqrt((boid->vex*boid->vex)+(boid->vey*boid->vey));
			dx=(boid->vex/magnitude)*RADIUS*5*boid->vem;
			dy=(boid->vey/magnitude)*RADIUS*5*boid->vem;
			
			if (magnitude>0) {
			glColor3f(0.0f, 0.0f, 1.0f);
			glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
			glBegin(GL_LINE_STRIP);
			glVertex2f(boid->x, boid->y);
			glVertex2f(boid->x+dx, boid->y+dy);
			glEnd();
			}
		}		
		
		if (random_vector) {
			magnitude = sqrt((boid->rex*boid->rex)+(boid->rey*boid->rey));
			dx=(boid->rex/magnitude)*RADIUS*3;
			dy=(boid->rey/magnitude)*RADIUS*3;
			
			if (magnitude>0) {
			glColor3f(1.0f, 0.5f, 0.0f);
			glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
			glBegin(GL_LINE_STRIP);
			glVertex2f(boid->x, boid->y);
			glVertex2f(boid->x+dx, boid->y+dy);
			glEnd();
			}
		}

		if (centering_sphere && boid->color==2) {
			radius=RADIUS*FLOCK_RADIUS;
			glColor3f(0.0f, 1.0f, 0.0f);
			glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
			glBegin(GL_LINE_STRIP);
			for (theta=0; theta<2.0*M_PI; theta+=delta_theta)
			{
				glVertex2f(boid->x+radius*cos(theta), boid->y+radius*sin(theta));
			}
			glVertex2f(boid->x+radius, boid->y);
			glEnd();
		}
	}
}

int rand6()
{
	int result;
	result = int((float)rand()/(float)RAND_MAX*6);
	if (result==6)
		result = 5;

	return result;
}

bool collide(BOID *a, BOID *b)
{
	float dist2;
	dist2 = (a->x - b->x)*(a->x - b->x) +
			(a->y - b->y)*(a->y - b->y);
	return (dist2<=4*RADIUS*RADIUS);
}

bool neighbour(BOID *a, BOID *b, float dist)
{
	float dist2;
	dist2 = (a->x - b->x)*(a->x - b->x) +
			(a->y - b->y)*(a->y - b->y);
	return (dist2<=dist*dist);
}

bool staticpos(float x, float y, float ox, float oy) {
	if (abs(x-ox)<0.003 && abs(y-oy)<0.003) {
		return true;
	}
	else {return false;}
}

float boiddist(BOID *a, BOID *b)
{
	float dist2;
	dist2 = (a->x - b->x)*(a->x - b->x) +
			(a->y - b->y)*(a->y - b->y);
	return sqrt(dist2);
}

float aDist(float a, float b) {
	float c = abs(a-b);
	if (c>180) {c=360-c;}
	return c;
}

float averageAngle(float a, float b) {
	float m,n;
	if (a<b) {m=a;n=b;}
	else {m=b;n=a;}

	float t1=(m+n)/2;
	float t2=(m+360+n)/2;
	if (t2>359) {t2-=360;}

	if ((aDist(t1,a)+aDist(t1,b))<(aDist(t2,a)+aDist(t2,b))) {
		return t1;
	}
	else {
		return t2;
	}

}

void UpdateBoids()
{
	BOID *p, *q, *r;
	float centx, centy, magnitude, rex, rey, angle, repel;
	int centc;
	p = boid_list;

	if (p) {
		// We consider all boids in turn
		while (p->next) {
			p->aex=0;p->aey=0;p->color=2;
			q = boid_list;
			centx=0; centy=0; centc=0;

			// Detect static obstacles
			// Must avoid no matter what!
			r = sob_list;
			while (r->next) {
				if (neighbour(p,r,(float)(RADIUS+r->radius+0.1))) {
					repel=boiddist(p,r);
					repel=(float)((RADIUS+r->radius+0.1)-(repel));
					p->aex+=((p->x-r->x)*repel*200);
					p->aey+=((p->y-r->y)*repel*200);
					if (neighbour(p,r,(float)(RADIUS+r->radius+0.01))) {
						p->color=1;
						repel=25;
						p->aex+=((p->x-r->x)*repel*10);
						p->aey+=((p->y-r->y)*repel*10);	
					}
				}
				r = r->next;
			}
			// Detect neighbouring boids
			while (q->next) {
				if (neighbour(p,q,RADIUS*COLL_RADIUS) && p!=q) {
					// 1. Collision Avoidance
					// The closer two boids are, the stronger the avoidance
					repel=boiddist(p,q);
					repel=25-(repel*repel);

					p->aex+=((p->x-q->x)*repel*1);
					p->aey+=((p->y-q->y)*repel*1);
					if (neighbour(p,q,(float)(RADIUS*2.25)) && p!=q) {
						p->color=1;
						p->aex+=((p->x-q->x)*repel*10);
						p->aey+=((p->y-q->y)*repel*10);						
					}
				}
				if (neighbour(p,q,RADIUS*NEIGH_RADIUS) && p!=q) {
					// 2. Velocity Matching
					// Average out the difference between this boid and all neighbouring boids
					// Will normalize later
					p->vex+=q->dx*5+q->vex;
					p->vey+=q->dy*5+q->vey;
					if (!staticpos(p->x,p->y,p->ox,p->oy)) p->vem=1;
				}
				if (neighbour(p,q,RADIUS*FLOCK_RADIUS) && p!=q) {
					if (p->color!=1) p->color=0;
					// 3. Flock Centering
					// Look slightly further and compute the centroid
					centx+=q->x;
					centy+=q->y;
					centc++;
				}

				q=q->next;
			}

			if ((p->color==2) || staticpos(p->x,p->y,p->ox,p->oy)) {
				// Velocity matching decays when no velocity to match
				// or when not moving
				p->vex=(float)(p->vex*0.99);
				p->vey=(float)(p->vey*0.99);
				p->vem=(float)(p->vem*0.99);
			}

			// Centroid complete
			if (centc>0) {
				centx=centx/centc;
				centy=centy/centc;
			}

			// Vector to that centroid
			p->cex=centx-p->x;
			p->cey=centy-p->y;
			// Normalize centering vector
			magnitude = sqrt((p->cex*p->cex)+(p->cey*p->cey));
			//printf("CENTE: %f\n",magnitude);
			p->cex=(float)((p->cex/magnitude)*0.2);
			p->cey=(float)((p->cey/magnitude)*0.2);

			// Collision avoidance should be near infinite when colliding
			magnitude = sqrt((p->aex*p->aex)+(p->aey*p->aey));

			// Random small change in direction
			// Do this only once in a while so that the 
			// net random movement will not tend towards zero
			// Or if the Boid is stuck
			if ((curfrtime-lastfrtime > RAND_TIME) || staticpos(p->x,p->y,p->ox,p->oy)) {
				angle = (float)(rand()%360);
				rex = (float)(sin((double)angle));
				rey = (float)(cos((double)angle));
				magnitude = sqrt((rex*rex)+(rey*rey));
				p->rex=(float)((rex/magnitude)*RAND_FACTOR);
				p->rey=(float)((rey/magnitude)*RAND_FACTOR);
			}
			p->dx=p->rex;
			p->dy=p->rey;

			// Normalize velocity vector
			magnitude = sqrt((p->vex*p->vex)+(p->vey*p->vey));
			p->vex=(float)(p->vex/magnitude);
			p->vey=(float)(p->vey/magnitude);

			// Aggregate all vectors into overall direction vector
			p->dx += p->vex+p->cex+p->aex;
			p->dy += p->vey+p->cey+p->aey;

			// Random small change in speed
			float randspeed = (float)(rand()%100+1);
			randspeed=randspeed/100;
			randspeed=1;

			// Normalize overall vector by speed
			magnitude = sqrt((p->dx*p->dx)+(p->dy*p->dy));
			p->dx=(float)((p->dx/magnitude)*SPEED*randspeed);
			p->dy=(float)((p->dy/magnitude)*SPEED*randspeed);

			// Backup current position
			p->ox=p->x;
			p->oy=p->y;
			
			// Update position according to direction vector
			p->x += p->dx;
			p->y += p->dy;

			// Avoid edges
			if (p->x < LEFT_BORDER) {p->vex+=1000;}
			if (p->x > RIGHT_BORDER) {p->vex-=1000;}
			if (p->y < DOWN_BORDER) {p->vey+=1000;}
			if (p->y > UP_BORDER) {p->vey-=1000;}

			p = p->next;
		}
	}

}

void Display(void)
{

	// Timer
	lasttime = curtime;
	curtime = ((float)glutGet(GLUT_ELAPSED_TIME))/1000;
	elaptime = curtime - lasttime;
	curfrtime += elaptime;

	SPEED=MAX_SPEED*elaptime;

	// Background
	glClearColor(1.0, 1.0, 1.0, 1);
	glClearDepth(1);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluOrtho2D(-1.0f, 1.0f, -1.0f, 1.0f);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	glViewport((GLint)0.0, (GLint)0.0, (GLint)screenwidth, (GLint)screenheight);

	// Update boid movements
	UpdateBoids();

	// Draw all static obstacles
	BOID *s;
	s = sob_list;
	while (s->next) {
		DrawBoid(s, s->radius, SLICE_NUM);
		s = s->next;
	}

	// Draw all boids
	BOID *p;
	p = boid_list;
	while (p->next) {
		DrawBoid(p, RADIUS, SLICE_NUM);
		p = p->next;
	}

	// Set timer variables
	if (curfrtime-lastfrtime>RAND_TIME) {lastfrtime=curfrtime;}

	glColor3f(1.0f, 0.0f, 0.0f);
	glutSwapBuffers();
}

void Keyboard(unsigned char key, int x, int y)
{
	switch (key)
	{
	case 'R':
		{
			boid_list = NULL;
			sob_list = NULL;
	
			InitBoids();
			InitObs();			
			DisplayConsole();
			curfrtime = RAND_TIME; lastfrtime = 0;
			break;
		}
	case 'B':
		{
			boid_list = NULL;
	
			InitBoids();
			DisplayConsole();
			curfrtime = RAND_TIME; lastfrtime = 0;
			break;
		}
	case 'Q':
		{
			if (directional_sphere&&collision_vector&&velocity_vector&&random_vector) {
				directional_sphere=false;
				collision_vector=false;
				velocity_vector=false;
				random_vector=false;
			}
			else {
				directional_sphere=true;
				collision_vector=true;
				velocity_vector=true;
				random_vector=true;
			}
			DisplayConsole();
			break;
		}
	case 'D':
		{
			directional_sphere=!directional_sphere;
			DisplayConsole();
			break;
		}
	case 'C':
		{
			collision_vector=!collision_vector;
			DisplayConsole();
			break;
		}
	case 'V':
		{
			velocity_vector=!velocity_vector;
			DisplayConsole();
			break;
		}
	case 'A':
		{
			random_vector=!random_vector;
			DisplayConsole();
			break;
		}
	case 'E':
		{
			centering_sphere=!centering_sphere;
			DisplayConsole();
			break;
		}
	case 'P':
		{
			if (RAND_FACTOR<1) {RAND_FACTOR+=(float)0.1;}
			else if (RAND_FACTOR>=1) {RAND_FACTOR=0;}
			else {}
			DisplayConsole();
			break;
		}
	case '+':
		{
			if (speedfactor<50) {speedfactor+=1;}
			MAX_SPEED = (float)(speedfactor*RADIUS);
			DisplayConsole();
			break;
		}
	case '-':
		{
			if (speedfactor>1) {speedfactor-=1;}
			MAX_SPEED = (float)(speedfactor*RADIUS);
			DisplayConsole();
			break;
		}
	case '1':
		{
			if (COLL_RADIUS<10) {COLL_RADIUS+=0.25;}
			else if (COLL_RADIUS==10) {COLL_RADIUS=3;}
			else {}
			DisplayConsole();
			break;
		}
	case '2':
		{
			if (NEIGH_RADIUS<20) {NEIGH_RADIUS+=0.25;}
			else if (NEIGH_RADIUS==20) {NEIGH_RADIUS=5;}
			else {}
			DisplayConsole();
			break;
		}
	case '3':
		{
			if (FLOCK_RADIUS<40) {FLOCK_RADIUS+=1;}
			else if (FLOCK_RADIUS==40) {FLOCK_RADIUS=5;}
			else {}
			DisplayConsole();
			break;
		}
	case '4':
		{
			if (BOID_NUM<100) {BOID_NUM+=5;}
			else if (BOID_NUM==100) {BOID_NUM=5;}
			else {}
			DisplayConsole();
			break;
		}
	case '5':
		{
			if (OBS_NUM<40) {OBS_NUM+=5;}
			else if (OBS_NUM==40) {OBS_NUM=0;}
			else {}
			DisplayConsole();
			break;
		}
	case 27:
		{
			exit(0);
			break;
		}
	}
}

void InitializeGlut(int *argc, char *argv[])
{
	glutInit(argc, argv);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
	glutInitWindowSize(screenwidth, screenheight);
	glutCreateWindow(argv[0]);
	glutDisplayFunc(Display);
	glutIdleFunc(Display);
	glutKeyboardFunc(Keyboard);
}

bool CheckOverlap(BOID *boid)
{
	BOID *p;
	bool overlap=false;
	p = boid_list;

	if (p) {
		while (p->next) {
			// Check overlap
			if (collide(p,boid)) {overlap=true;}
			p = p->next;
		}
	}

	return overlap;
}

void InsertBoid(BOID *boid)
{
	BOID *p;
	p = boid_list;
	if (!p)
		boid_list = boid;
	else
	{
		while (p->next)
			p = p->next;
		boid->next = NULL;
		p->next = boid;
	}
}

void InsertObs(BOID *boid)
{
	BOID *p;
	p = sob_list;
	if (!p)
		sob_list = boid;
	else
	{
		while (p->next)
			p = p->next;
		boid->next = NULL;
		p->next = boid;
	}
}

void InitBoids()
{
	float angle, magnitude;
	int i;

	for (i=0; i<=BOID_NUM; i++)
	{
		BOID *boid = new BOID;
		bool boid_overlap = true;
		boid->id=i;
		boid->color = i%6;
		boid->radius=0;
		boid->vem=1;
		while (boid_overlap) {
			// Randomize Boid position
			boid->x = (rand()%(int)((abs(LEFT_BORDER*1000)+abs(RIGHT_BORDER*1000)))+(LEFT_BORDER*1000))/1000;
			boid->y = (rand()%(int)((abs(DOWN_BORDER*1000)+abs(UP_BORDER*1000)))+(DOWN_BORDER*1000))/1000;
			// Give random direction angle from 0 to 359
			angle = (float)(rand()%360);
			boid->vex = (float)(sin((double)angle));
			boid->vey = (float)(cos((double)angle));
			// Normalize
			magnitude = sqrt((boid->vex*boid->vex)+(boid->vey*boid->vey));
			boid->vex=(float)((boid->vex/magnitude)*SPEED);
			boid->vey=(float)((boid->vey/magnitude)*SPEED);
			// Check for overlap
			boid_overlap = CheckOverlap(boid);
		}
		boid->next = NULL;
		InsertBoid(boid);
	}
}

void InitObs()
{
	float rad;
	int i;

	for (i=0; i<=OBS_NUM; i++)
	{
		BOID *boid = new BOID;
		boid->id=i;
		boid->color = 5;

		// Randomize Boid position
		boid->x = (rand()%(int)((abs(LEFT_BORDER*1000)+abs(RIGHT_BORDER*1000)))+(LEFT_BORDER*1000))/1000;
		boid->y = (rand()%(int)((abs(DOWN_BORDER*1000)+abs(UP_BORDER*1000)))+(DOWN_BORDER*1000))/1000;

		// Give random radius up to 0.1
		rad = (float)(rand()%10);
		rad = rad/100;
		rad+=(float)0.02;
		boid->radius=rad;

		boid->next = NULL;
		InsertObs(boid);
	}
}

void DisplayConsole() {
	// Instructions and details in the console
	system("CLS");
	cout << "CS2306S Boid Flocking Simple 2D Simulation \n\n";

	printf("R  : Restart simulation\n");
	printf("B  : Reset Boids only (not obstacles)\n\n");

	printf("Q  : Toggle ALL Vectors");
	if (directional_sphere&&collision_vector&&velocity_vector&&random_vector) {
		printf(" OFF");} else {printf(" ON");}
	printf("\n");
	printf("D  : Toggle Directional Sphere");
	if (directional_sphere) {printf(" OFF");} else {printf(" ON");}
	printf("\n");
	printf("C  : Toggle Collision Avoidance Vector");
	if (collision_vector) {printf(" OFF");} else {printf(" ON");}
	printf("\n");
	printf("V  : Toggle Velocity Matching Vector");
	if (velocity_vector) {printf(" OFF");} else {printf(" ON");}
	printf("\n");
	printf("A  : Toggle Random Vector");
	if (random_vector) {printf(" OFF");} else {printf(" ON");}
	printf("\n\n");

	printf("E  : Toggle Flock Centering Sphere");
	if (centering_sphere) {printf(" OFF");} else {printf(" ON");}
	printf("\n");
	printf("P  : Loop through Random Factor (currently ");
	printf("%2.2f",RAND_FACTOR);
	printf(") \n\n");

	printf("+/-: Increase/Decrease Boid Speed (currently ");
	printf("%d",speedfactor);
	printf(") \n");
	printf("1  : Loop through Collision Radius (currently ");
	printf("%2.2f",COLL_RADIUS);
	printf(") \n");
	printf("2  : Loop through Neighbour Radius (currently ");
	printf("%2.2f",NEIGH_RADIUS);
	printf(") \n");
	printf("3  : Loop through Flock Radius (currently ");
	printf("%2.2f",FLOCK_RADIUS);
	printf(") \n\n");

	printf("These settings will only take effect after restarting the simulation:\n");
	printf("4  : Loop through Boid Number (currently ");
	printf("%d",BOID_NUM);
	printf(") \n");
	printf("5  : Loop through Obstacle Number (currently ");
	printf("%d",OBS_NUM);
	printf(") \n\n");

	printf("ESC: Exit Program\n");

}


int main(int argc, char *argv[])
{
	srand((unsigned int)time(0));  // Initialize random number generator.
	screenwidth = screenheight = 600;
	InitializeGlut(&argc, argv);
    
	boid_list = NULL;
	sob_list = NULL;
	
	InitBoids();
	InitObs();

	DisplayConsole();

	glutMainLoop();

	return 0;
}