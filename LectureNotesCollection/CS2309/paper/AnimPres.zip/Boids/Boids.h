#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <GL/freeglut.h>
#include <conio.h>
#include <ctime>

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif
int BOID_NUM=20;
int OBS_NUM=20;
#define SLICE_NUM 20
#define RAND_TIME 1
#define RADIUS 0.02f
#define LEFT_BORDER -0.9f
#define RIGHT_BORDER 0.9f
#define UP_BORDER 0.9f
#define DOWN_BORDER -0.9f
#define DELTA_ANGLE 5.0/360.0*M_PI

int speedfactor=15;
float MAX_SPEED = (float)(speedfactor*RADIUS);

float COLL_RADIUS=3;
float NEIGH_RADIUS=7;
float FLOCK_RADIUS=20;
float RAND_FACTOR=0.5;

typedef struct BOID{
	float x, y;
	float ox, oy;
	int id;
	int color;
	
	float dx;		// Overall vector
	float dy;
	
	float aex;		// Collision avoidance vector
	float aey;
	float vex;		// Velocity matching vector
	float vey;
	float vem;
	float cex;		// Centering vector
	float cey;
	float rex;		// Random vector
	float rey;
	float vel;		// Velocity magnitude (0=stopped, 1=max)

	float radius;	// Only used for obstacles of various sizes

	BOID *next;
}BOID;

int screenwidth, screenheight;
int current_frame, current_subframe;
float boid_color[6][3] = {{0.0, 0.0, 0.0},
						{1.0, 0.0, 0.0},
						{0.0, 1.0, 0.0},
						{0.0, 0.0, 0.0},
						{0.0, 0.0, 0.0},
						{0.5, 0.5, 0.5}};
BOID *boid_list, *sob_list;
float boid_dir;

bool directional_sphere=true;
bool collision_vector=true;
bool velocity_vector=true;
bool random_vector=true;
bool centering_sphere=true;

void InitializeGlut(int *argc, char *argv[]);
void Display(void);
void Keyboard(unsigned char key, int x, int y);
void DrawBoid(BOID *boid, float radius, float slices);
int rand6();

bool CheckOverlap(BOID *boid);
void InsertBoid(BOID *boid);
void InsertObs(BOID *boid);
void InitBoids();
void InitObs();
void UpdateBoids();
bool collide(BOID *a, BOID *b);
bool neighbour(BOID *a, BOID *b, float dist);
bool staticpos(float x, float y, float ox, float oy);
float boiddist(BOID *a, BOID *b);

float aDist(float a, float b);
float averageAngle(float a, float b);

void DisplayConsole();
