package sg.edu.nus.cs2020.solutions;

public enum TreeVerifierCheck {
	Weight, Structure, Balance, Parent
};