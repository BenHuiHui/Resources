import java.util.*;

class Q05Stack {
  public static void main(String[] args) {
    Stack < Integer > S1 = new Stack < Integer > ();
    Stack < Integer > S2 = new Stack < Integer > ();
    Stack < Integer > S3 = new Stack < Integer > ();

    // You can change these numbers to play around with this code
    //S1.push(7); S1.push(5); S1.push(2); S1.push(9);
    S1.push(4); S1.push(1); S1.push(2); S1.push(3); S1.push(5); S1.push(7); S1.push(6);
    System.out.println("BEFORE: " + S1);

    while (!S1.empty()) {
      while (!S3.empty() && S3.peek() >= S1.peek())
        S2.push(S3.pop());
      S3.push(S1.pop());
      while (!S2.empty())
        S3.push(S2.pop());
    }

    while (!S3.empty())
      S1.push(S3.pop());

    System.out.println("AFTER : " + S1);
  }
}
