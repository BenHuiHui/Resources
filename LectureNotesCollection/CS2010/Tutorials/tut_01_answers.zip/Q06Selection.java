import java.util.*;

class Q06Selection {
  static int Partition(int[] A, int l, int r) {
    int x = A[r], i = l - 1, temp;

    for (int j = l; j < r; j++)
      if (A[j] <= x) {
        i++;
        temp = A[i];
        A[i] = A[j];
        A[j] = temp;
      }
    
    temp = A[i + 1];
    A[i + 1] = A[r];
    A[r] = temp;

    return i + 1;
  }

  static int Randomized_Partition(int[] A, int l, int r) {
    Random rnd = new Random();
    int i = l + rnd.nextInt(r - l + 1);

    int temp = A[r];
    A[r] = A[i];
    A[i] = temp;

    return Partition(A, l, r);
  }

  static int Select(int[] A, int l, int r, int k) {
    if (l == r)
      return A[l];

    int PivotIndex = Randomized_Partition(A, l, r);

    if (PivotIndex == k - 1)
      return A[PivotIndex];
    else if (PivotIndex > k - 1)
      return Select(A, l, PivotIndex - 1, k);
    else
      return Select(A, PivotIndex + 1, r, k);
  }

  public static void main(String[] args) {
    int[] A = new int[] { 2, 8, 7, 1, 5, 4, 6, 3 }; // this is just a permutation of [1..8]

    System.out.println(Select(A, 0, 7, 8)); // the output must be 8
    System.out.println(Select(A, 0, 7, 7)); // the output must be 7
    System.out.println(Select(A, 0, 7, 6)); // the output must be 6
    System.out.println(Select(A, 0, 7, 5)); // the output must be 5
    System.out.println(Select(A, 0, 7, 4)); // the output must be 4
    System.out.println(Select(A, 0, 7, 3)); // the output must be 3
    System.out.println(Select(A, 0, 7, 2)); // the output must be 2
    System.out.println(Select(A, 0, 7, 1)); // the output must be 1

    // try experimenting with the content of array A to see the behavior of "Select"
  }
}
