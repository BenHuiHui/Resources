import java.util.*;

class SchedulingDeliveriesGen {
  public static void main(String[] args) {
    int N = 2 * (26*26*26 + 1) + 62 + 2 * (26*26*26);
    Random r = new Random();

    System.out.println(N);
    // first, populate the PriorityQueue with "dummy three-characters mothers" to make PQ size ~ 20K
    for (int i = 0; i < 26; i++)
      for (int j = 0; j < 26; j++)
        for (int k = 0; k < 26; k++) {
          String name = "" + (char)('A' + i) + (char)('A' + j) + (char)('A' + k);
          System.out.println("0 " + name + " 30"); // all these women have dilation = 30 millimeters
        }
    System.out.println("3"); // the answer should be "AAA", the first dummy mother

    // update dilation
    for (int i = 0; i < 26; i++)
      for (int j = 0; j < 26; j++)
        for (int k = 0; k < 26; k++) {
          String name = "" + (char)('A' + i) + (char)('A' + j) + (char)('A' + k);
          int dilation = 0 + r.nextInt(25); // [0..24]
          System.out.println("1 " + name + " " + dilation); // these women increase their dilation RANDOMLY
        }
    System.out.println("3");



    // insert the original Subtask2.txt here (when the priority queue is still quite full)



    // at the end, make all these dummy mothers give birth one by one, and ask who is in the front of the queue
    // if student order these mothers wrongly, they will get wrong answer
    for (int i = 0; i < 26; i++)
      for (int j = 0; j < 26; j++)
        for (int k = 0; k < 26; k++) {
          String name = "" + (char)('A' + i) + (char)('A' + j) + (char)('A' + k);
          System.out.println("2 " + name);
          System.out.println("3");
        }
    // the last answer should be "The delivery suite is empty"
  }
}
